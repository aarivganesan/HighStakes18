#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor rightFront = motor(PORT9, ratio18_1, false);
motor rightBack = motor(PORT15, ratio18_1, false);
motor rightMid = motor(PORT21, ratio18_1, false);
motor leftFront = motor(PORT4, ratio18_1, true);
motor leftBack = motor(PORT14, ratio18_1, true);
motor leftMid = motor(PORT12, ratio18_1, true);
controller Controller1 = controller(primary);
motor Intake = motor(PORT1, ratio36_1, true);
inertial Inertial = inertial(PORT19);
digital_out MOGO = digital_out(Brain.ThreeWirePort.A);
distance detected = distance(PORT2);
motor Upper = motor(PORT20, ratio18_1, false);
digital_out mogo = digital_out(Brain.ThreeWirePort.B);
optical opticalsensor = optical(PORT3);
distance aligner = distance(PORT13);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}